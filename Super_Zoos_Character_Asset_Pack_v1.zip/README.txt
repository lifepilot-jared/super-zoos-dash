SUPER ZOOS CHARACTER ASSET PACK v1

Upload all PNG files into:
public/images/characters/animation/

Keep every filename exactly as supplied.

The pack contains:
- Four normal Peter running frames
- Super Peter movement and look-back frames
- Four normal Judy running frames
- Super Judy movement and look-back frames

These are transparent PNG assets prepared from the supplied sprite sheet.
